package com.praveen.batch;

import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class BatchScheduler {

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job exportAdjustmentJob;

    @Scheduled(cron = "0 0 2 * * *")
    public void runJob() throws Exception {
        JobParameters params = new JobParametersBuilder()
                .addDate("runDate", new Date())
                .toJobParameters();

        JobExecution execution = jobLauncher.run(exportAdjustmentJob, params);
        System.out.println("Job Status: " + execution.getStatus());
    }
}