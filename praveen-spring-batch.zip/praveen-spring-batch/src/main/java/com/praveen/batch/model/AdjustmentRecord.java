package com.praveen.batch.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AdjustmentRecord {
    private String remitSeqNbr;
    private String remitClmSeqNbr;
    private String adjustCdSeqNbr;
    private String remitSegId;
    private String remitCd;
    private String adjustAmt;
}