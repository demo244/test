CREATE TABLE adjustments (
    remit_seq_nbr VARCHAR(20),
    remit_clm_seq_nbr VARCHAR(20),
    adjust_cd_seq_nbr VARCHAR(20),
    remit_seg_id VARCHAR(10),
    remit_cd VARCHAR(10),
    adjust_amt DECIMAL(10,2)
);