package com.praveen.batch.mfp835.common.writer;

import org.springframework.batch.item.file.FlatFileFooterCallback;

import java.io.Writer;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

public class LineCountFooterCallback implements FlatFileFooterCallback {

    private final AtomicInteger counter;

    public LineCountFooterCallback(AtomicInteger counter) {
        this.counter = counter;
    }

    @Override
    public void writeFooter(Writer writer) throws IOException {
        writer.write("T|" + counter.get());
    }
}