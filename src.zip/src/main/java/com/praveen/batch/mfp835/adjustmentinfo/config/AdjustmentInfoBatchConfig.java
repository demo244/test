package com.praveen.batch.mfp835.adjustmentinfo.config;

import com.praveen.batch.mfp835.adjustmentinfo.model.AdjustmentRecord;
import com.praveen.batch.mfp835.common.writer.LineCountFooterCallback;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.LineAggregator;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import javax.sql.DataSource;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class AdjustmentInfoBatchConfig {

    private final JobBuilderFactory jobBuilderFactory;
    private final StepBuilderFactory stepBuilderFactory;
    private final DataSource dataSource;

    @Value("${batch.mfp835.adjustmentInfo.chunk.size}")
    private int chunkSize;

    @Value("${batch.mfp835.adjustmentInfo.output.file.prefix}")
    private String filePrefix;

    @Value("${batch.mfp835.adjustmentInfo.output.file.dir}")
    private String outputDir;

    @Bean(name = "exportAdjustmentInfoJob")
    public Job exportAdjustmentInfoJob() {
        return jobBuilderFactory.get("exportAdjustmentInfoJob")
                .start(exportAdjustmentInfoStep())
                .build();
    }

    @Bean
    public Step exportAdjustmentInfoStep() {
        return stepBuilderFactory.get("exportAdjustmentInfoStep")
                .<AdjustmentRecord, AdjustmentRecord>chunk(chunkSize)
                .reader(adjustmentInfoReader())
                .writer(adjustmentInfoWriter())
                .build();
    }

    @Bean
    public JdbcCursorItemReader<AdjustmentRecord> adjustmentInfoReader() {
        JdbcCursorItemReader<AdjustmentRecord> reader = new JdbcCursorItemReader<>();
        reader.setDataSource(dataSource);
        reader.setSql("SELECT remit_seq_nbr, remit_clm_seq_nbr, adjust_cd_seq_nbr, remit_seg_id, remit_cd, adjust_amt FROM adjustments");
        reader.setRowMapper((rs, rowNum) -> AdjustmentRecord.builder()
                .remitSeqNbr(rs.getString("remit_seq_nbr"))
                .remitClmSeqNbr(rs.getString("remit_clm_seq_nbr"))
                .adjustCdSeqNbr(rs.getString("adjust_cd_seq_nbr"))
                .remitSegId(rs.getString("remit_seg_id"))
                .remitCd(rs.getString("remit_cd"))
                .adjustAmt(rs.getBigDecimal("adjust_amt").toPlainString())
                .build());
        return reader;
    }

    @Bean
    public FlatFileItemWriter<AdjustmentRecord> adjustmentInfoWriter() {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMddyyyy_HHmmss"));
        String filename = filePrefix + timestamp + ".txt";
        String fullPath = Paths.get(outputDir, filename).toString();

        FlatFileItemWriter<AdjustmentRecord> writer = new FlatFileItemWriter<>();
        writer.setResource(new FileSystemResource(fullPath));

        AtomicInteger counter = new AtomicInteger(0);

        writer.setLineAggregator((LineAggregator<AdjustmentRecord>) item -> {
            counter.incrementAndGet();
            return String.join("|",
                    item.getRemitSeqNbr(),
                    item.getRemitClmSeqNbr(),
                    item.getAdjustCdSeqNbr(),
                    item.getRemitSegId(),
                    item.getRemitCd(),
                    item.getAdjustAmt()) + "|";
        });

        writer.setHeaderCallback(writer1 -> writer1.write("REMIT_SEQ_NBR|REMIT_CLM_SEQ_NBR|ADJUST_CD_SEQ_NBR|REMIT_SEG_ID|REMIT_CD|ADJUST_AMT|"));
        writer.setFooterCallback(new LineCountFooterCallback(counter));

        return writer;
    }
}
