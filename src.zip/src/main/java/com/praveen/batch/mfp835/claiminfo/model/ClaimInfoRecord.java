package com.praveen.batch.mfp835.claiminfo.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ClaimInfoRecord {
    private String remitSeqNbr;
    private String remitClmSeqNbr;
    private String svcProvId;
    private String svcProvDol;
    private String billedAmt;
    private String scriptSvcRefrNbrId;
    private String clmStatCd;
    private String totClmChrgAmt;
    private String clmPymtAmt;
}
