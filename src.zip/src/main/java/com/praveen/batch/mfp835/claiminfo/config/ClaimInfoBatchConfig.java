package com.praveen.batch.mfp835.claiminfo.config;

import com.praveen.batch.mfp835.claiminfo.model.ClaimInfoRecord;
import com.praveen.batch.mfp835.common.writer.LineCountFooterCallback;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import javax.sql.DataSource;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class ClaimInfoBatchConfig {

    private final JobBuilderFactory jobBuilderFactory;
    private final StepBuilderFactory stepBuilderFactory;
    private final DataSource dataSource;

    @Value("${batch.mfp835.claimInfo.chunk.size}")
    private int chunkSize;

    @Value("${batch.mfp835.claimInfo.output.file.prefix}")
    private String filePrefix;

    @Value("${batch.mfp835.claimInfo.output.file.dir}")
    private String outputDir;

    @Bean(name = "exportClaimInfoJob")
    public Job exportClaimInfoJob() {
        return jobBuilderFactory.get("exportClaimInfoJob")
                .start(exportClaimInfoStep())
                .build();
    }

    @Bean
    public Step exportClaimInfoStep() {
        return stepBuilderFactory.get("exportClaimInfoStep")
                .<ClaimInfoRecord, ClaimInfoRecord>chunk(chunkSize)
                .reader(claimInfoReader())
                .writer(claimInfoWriter())
                .build();
    }

    @Bean
    public JdbcCursorItemReader<ClaimInfoRecord> claimInfoReader() {
        JdbcCursorItemReader<ClaimInfoRecord> reader = new JdbcCursorItemReader<>();
        reader.setDataSource(dataSource);
        reader.setSql("SELECT remit_seq_nbr, remit_clm_seq_nbr, svc_prov_id, svc_prov_dol, billed_amt, script_svc_refr_nbr_id, clm_stat_cd, tot_clm_chrg_amt, clm_pymt_amt FROM claim_info");

        reader.setRowMapper((rs, rowNum) -> ClaimInfoRecord.builder()
                .remitSeqNbr(rs.getString("remit_seq_nbr"))
                .remitClmSeqNbr(rs.getString("remit_clm_seq_nbr"))
                .svcProvId(rs.getString("svc_prov_id"))
                .svcProvDol(rs.getString("svc_prov_dol"))
                .billedAmt(rs.getString("billed_amt"))
                .scriptSvcRefrNbrId(rs.getString("script_svc_refr_nbr_id"))
                .clmStatCd(rs.getString("clm_stat_cd"))
                .totClmChrgAmt(rs.getString("tot_clm_chrg_amt"))
                .clmPymtAmt(rs.getString("clm_pymt_amt"))
                .build());
        return reader;
    }

    @Bean
    public FlatFileItemWriter<ClaimInfoRecord> claimInfoWriter() {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMddyyyy_HHmmss"));
        String filename = filePrefix + timestamp + ".txt";
        String fullPath = Paths.get(outputDir, filename).toString();

        FlatFileItemWriter<ClaimInfoRecord> writer = new FlatFileItemWriter<>();
        writer.setResource(new FileSystemResource(fullPath));

        AtomicInteger counter = new AtomicInteger(0);

        writer.setLineAggregator(item -> {
            counter.incrementAndGet();
            return String.join("|",
                    item.getRemitSeqNbr(),
                    item.getRemitClmSeqNbr(),
                    item.getSvcProvId(),
                    item.getSvcProvDol(),
                    item.getBilledAmt(),
                    item.getScriptSvcRefrNbrId(),
                    item.getClmStatCd(),
                    item.getTotClmChrgAmt(),
                    item.getClmPymtAmt()
            ) + "|";
        });

        writer.setHeaderCallback(w -> w.write("REMIT_SEQ_NBR|REMIT_CLM_SEQ_NBR|SVC_PROV_ID|SVC_PROV_DOL|BILLED_AMT|SCRIPT_SVC_REFR_NBR_ID|CLM_STAT_CD|TOT_CLM_CHRG_AMT|CLM_PYMT_AMT|"));
        writer.setFooterCallback(new LineCountFooterCallback(counter));

        return writer;
    }


}
