CREATE TABLE adjustments (
    remit_seq_nbr VARCHAR(20),
    remit_clm_seq_nbr VARCHAR(20),
    adjust_cd_seq_nbr VARCHAR(20),
    remit_seg_id VARCHAR(10),
    remit_cd VARCHAR(10),
    adjust_amt DECIMAL(10,2)
);

CREATE TABLE claim_info (
    remit_seq_nbr VARCHAR(20),
    remit_clm_seq_nbr VARCHAR(20),
    svc_prov_id VARCHAR(20),
    svc_prov_dol VARCHAR(20),
    billed_amt VARCHAR(20),
    script_svc_refr_nbr_id VARCHAR(50),
    clm_stat_cd VARCHAR(20),
    tot_clm_chrg_amt VARCHAR(20),
    clm_pymt_amt VARCHAR(20)
);
