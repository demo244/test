INSERT INTO adjustments VALUES ('2337321001', '32356894022', '7263429494001', 'CASSVC', 'CO130', 0.28);
INSERT INTO adjustments VALUES ('2337321001', '32356894022', '7263429495001', 'CASSVC', 'CO91', 8.46);
INSERT INTO adjustments VALUES ('2337321001', '32356894022', '7263429496001', 'CASSVC', 'CO130', -0.28);

INSERT INTO claim_info (
    remit_seq_nbr, remit_clm_seq_nbr, svc_prov_id, svc_prov_dol,
    billed_amt, script_svc_refr_nbr_id, clm_stat_cd,
    tot_clm_chrg_amt, clm_pymt_amt
) VALUES
('RMT001', 'CLM001', 'PROV1001', '2025-06-20', '150.00', 'REF1234567890', 'PAID', '150.00', '145.00'),
('RMT002', 'CLM002', 'PROV1002', '2025-06-21', '300.00', 'REF1234567891', 'DENIED', '300.00', '0.00'),
('RMT003', 'CLM003', 'PROV1003', '2025-06-22', '200.00', 'REF1234567892', 'PAID', '200.00', '190.00'),
('RMT004', 'CLM004', 'PROV1004', '2025-06-23', '250.00', 'REF1234567893', 'PENDING', '250.00', '0.00'),
('RMT005', 'CLM005', 'PROV1005', '2025-06-24', '175.00', 'REF1234567894', 'PAID', '175.00', '170.00');
